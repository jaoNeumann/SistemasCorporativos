// ./controllers/depositController.js

class depositController{
    constructor(depositService){
        this.despoitService = depositService;
    }
    // Metodo create
    async create(req, res){
        const {name, status} = req.body;
        try {
            const newdeposit = await this.depositService.create(name, status);
            res.status(200).json(newDeposit);
        } catch (error) {
            res.status(500).json({error:'Erro ao inserir o novo deposito.'});
        }
    }
    async findAll(req, res) {
        try {
            const allDeposits = await this.depositService.findAll();
            res.status(200).json(allDeposits);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao buscar todos os depósitos.' });
        }
    }

    async findById(req, res) {
        const { depositId } = req.params;
        try {
            const deposit = await this.depositService.findById(depositId);
            res.status(200).json(deposit);
        } catch (error) {
            res.status(404).json({ error: error.message });
        }
    }

    async getPosicaoByProdutoInDeposito(req, res) {
        const { productId, depositId } = req.params;
        try {
            const posicaoProduto = await this.depositService.getPosicaoByProdutoInDeposito(productId, depositId);
            // Retorne a posição do produto e a quantidade, se aplicável
            res.status(200).json(posicaoProduto);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao buscar a posição do produto no depósito.' });
        }
    }

}

module.exports = depositController;