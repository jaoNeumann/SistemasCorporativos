// .routes/users.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const userService = require('../services/userService');// classe
const UserService = new userService(db.User);// Construção do objeto

const userController = require('../controllers/userController');// classe
const UserController = new userController(UserService);// Construção do objeto


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('Módulo de usuários está rodando.');
});

// Rota para criar um novo usuário
router.post('/novoUsuario', function(req, res, next){
  UserController.create(req, res);
});

// Rota para localizar usuario
router.get('/localisaTodosUsuarios', function(req, res, next){
  UserController.localizaTodosUsuarios(req, res);
});

// Rota para executar login
router.post('/login', function(req, res, next){
  UserController.login(req, res);
});

// Rota para localizar usuario pelo ID
router.get('/localisaUsuarioId', function(req, res, next){
  UserController.localisaUsuarioId(req, res);
});

module.exports = router;
