// ./routes/movimentos.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const MovimentoProdutoService = require('../services/movimentoProdutoService');
const movimentoProdutoService = new MovimentoProdutoService(db.MovimentoProduto, db.Deposit, db.Product);

const MovimentoProdutoController = require('../controllers/movimentoProdutoController');
const movimentoProdutoController = new MovimentoProdutoController(movimentoProdutoService);

/* GET movimentos listing. */
router.get('/', function(req, res, next) {
    res.send('Módulo de movimentos de produtos está rodando.');
});

// Rota para criar um novo movimento
router.post('/novoMovimento', function(req, res, next) {
    movimentoProdutoController.create(req, res);
});

// Rota para listar todos os movimentos
router.get('/todosMovimentos', function(req, res, next) {
    movimentoProdutoController.findAll(req, res);
});

// Rota para localizar um movimento pelo ID
router.get('/movimento/:movimentoId', function(req, res, next) {
    movimentoProdutoController.findById(req, res);
});

// Rota para adicionar produto ao depósito
router.post('/addProduct', function(req, res, next) {
    movimentoProdutoController.addProductToDeposit(req, res);
});

// Rota para remover produto do depósito
router.post('/removeProduct', function(req, res, next) {
    movimentoProdutoController.removeProductFromDeposit(req, res);
});

module.exports = router;
