// ./services/departmentService.js
const db = require('../models');

class DepartmentService {
    constructor(departmentModel) {
        this.Department = departmentModel;
    }

    async create(name) {
        try {
            const newDepartment = await this.Department.create({ name });
            return newDepartment;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allDepartments = await this.Department.findAll();
            return allDepartments;
        } catch (error) {
            throw error;
        }
    }

    async findById(departmentId) {
        try {
            const department = await this.Department.findByPk(departmentId);
            if (!department) {
                throw new Error(`Department with ID ${departmentId} not found.`);
            }
            return department;
        } catch (error) {
            throw error;
        }
    }

    async update(departmentId, newData) {
        try {
            const [updatedRowsCount, updatedRows] = await this.Department.update(newData, {
                where: { id: departmentId },
                returning: true
            });
            if (updatedRowsCount === 0) {
                throw new Error(`Department with ID ${departmentId} not found.`);
            }
            return updatedRows[0];
        } catch (error) {
            throw error;
        }
    }

    async delete(departmentId) {
        try {
            const rowsDeleted = await this.Department.destroy({
                where: { id: departmentId }
            });
            if (rowsDeleted === 0) {
                throw new Error(`Department with ID ${departmentId} not found.`);
            }
        } catch (error) {
            throw error;
        }
    }
}

module.exports = DepartmentService;
