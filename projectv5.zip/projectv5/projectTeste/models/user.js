// ./models/users.js
const Sequelize = require('sequelize');

// versão padrão
// const User = sequelize.define('User',{
//     id:{
//         type: Sequelize.INTEGER,
//         autoIncrement:true,
//         primatyKey:true
//     },
//     nome:{
//         type:sequelize.STRING,
//         allowNull:false,
//     },
//     email:{
//         type:sequelize.STRING,
//         allowNull:false,
//         unique:true
//     },
//     senha:{
//         type:sequelize.STRING,
//         allowNull:false,
//     }
// });

// versão Escobar (obviamente melhor)
module.exports= (sequelize) => {
    const User = sequelize.define('User',{
        id:{
            type: Sequelize.INTEGER,
            primaryKey:true,
            autoIncrement: true
        },
        login:{
            type:Sequelize.STRING,
            allowNull:false,
        },
        nome:{
            type:Sequelize.STRING,
            allowNull:false,
        },
        email:{
            type:Sequelize.STRING,
            allowNull:false,
            unique:true
        },
        senha:{
            type:Sequelize.STRING,
            allowNull:false,
        },
        departmentId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Departments',
                key: 'id'
            }
        }
    });
    return User;
};
