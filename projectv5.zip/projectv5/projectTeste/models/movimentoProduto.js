// ./models/movimentoProduto.js
const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const MovimentoProduto = sequelize.define('MovimentoProduto', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        tipoMovimento: {
            type: Sequelize.ENUM('entrada', 'saida'),
            allowNull: false
        },
        quantidade: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        precoUnitario: {
            type: Sequelize.DECIMAL(10, 2),
            allowNull: false
        },
        data: {
            type: Sequelize.DATE,
            allowNull: false,
            defaultValue: Sequelize.NOW
        }
    });

    MovimentoProduto.associate = (models) => {
        MovimentoProduto.belongsTo(models.Deposit, {
            foreignKey: 'depositoId',
            as: 'deposito'
        });

        MovimentoProduto.belongsTo(models.Product, {
            foreignKey: 'produtoId',
            as: 'produto'
        });
    };

    return MovimentoProduto;
};
