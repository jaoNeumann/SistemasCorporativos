// ./controllers/userController.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

class userController{
    constructor(userService){
        this.userService = userService;
    }
    // Metodo cadastro
    async create(req, res){
        const {login, nome, email, senha} = req.body;
        try {
            const novoUser = await this.userService.create(login, nome, email, senha);
            res.status(200).json(novoUser);
        } catch (error) {
            res.status(500).json({error:'Erro ao inserir o novo usuário.'});
        }
    }
    // Metodo login
    async login(req, res) {
        const { login, senha } = req.body;
        try{
            const token = await this.userService.login(login, senha);
            res.status(200).json( "Token:" + token );
        } catch (error) {
            res.status(500).json({ error: 'Erro ao realizar login' });
        }
    }

    // Metodo lista users
    async localizaTodosUsuarios(req, res){
        const {login, senha} = req.body;
        try {
            const allUsers = await this.userService.localizaTodosUsuarios(login, senha);
            res.status(200).json(allUsers);
        } catch (error){
            res.status(400).json({error:'Login inválido.'})
        }

    }

    // Metodo localiza users pelo ID
    async localisaUsuarioId(req, res){
        const {login, id} = req.body;
        try {
            const allUsers = await this.userService.localisaUsuarioId(login, id);
            res.status(200).json(allUsers);
        } catch (error){
            res.status(400).json({error:'Login inválido.'})
        }

    }
}

module.exports = userController;