// ./controllers/productController.js

class productController{
    constructor(productService){
        this.productService = productService;
    }
    // Metodo create
    async create(req, res){
        const {name, status} = req.body;
        try {
            const newProduct = await this.productService.create(name, status);
            res.status(200).json(newProduct);
        } catch (error) {
            res.status(500).json({error:'Erro ao inserir o novo produto.'});
        }
    }
    // Metodo update produto (necessário receber identificação do produto)
    async update(req, res) {
        const { productId } = req.params; // Correção: req.params.productId para acessar o ID do produto
        const newData = req.body;
        try {
            const updatedProduct = await this.productService.update(productId, newData);
            res.status(200).json(updatedProduct);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao atualizar o produto.' });
        }
    }   

    async findAll(req, res){
        try {
            const allProducts = await this.productService.findAll();
            res.status(200).json(allProducts);
        } catch (error){
            res.status(400).json({error:'Produto inválido.'})
        }

    }
    
    async findById(req, res){
        const {id} = req.body;
        try {
            const allProducts = await this.productService.findById(id);
            res.status(200).json(allProducts);
        } catch (error){
            res.status(400).json({error:'Produto inválido.'})
        }

    }
}
module.exports = productController;