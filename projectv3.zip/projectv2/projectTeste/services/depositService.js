//. /services/depositService.js
const db = require('../models');


class depositService{
    //construtor da classe recebe a depositModel
    constructor(depositModel){
        this.Deposit = depositModel;
    }
    async create(name, status) {
        try {
            const newDeposit = await this.Deposit.create({
                name: name,
                status: status
            });
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allDeposits = await this.Deposit.findAll();
            return allDeposits;
        } catch (error) {
            throw error;
        }
    }

    async findById(depositId) {
        try {
            const deposit = await this.Deposit.findByPk(depositId);
            if (!deposit) {
                throw new Error(`Depósito com o ID ${depositId} não encontrado.`);
            }
            return deposit;
        } catch (error) {
            throw error;
        }
    }

    async getPosicaoByProdutoInDeposito(productId, depositId) {
        try {
            // Verifica se o produto está no depósito
            const product = await this.Product.findByPk(productId);
            if (!product) {
                throw new Error(`Produto com o ID ${productId} não encontrado.`);
            }

            // Verifica se o depósito existe
            const deposit = await this.Deposit.findByPk(depositId);
            if (!deposit) {
                throw new Error(`Depósito com o ID ${depositId} não encontrado.`);
            }

            // Aqui você irá implementar a lógica para encontrar a posição do produto no depósito
            // Pode ser um processo de consulta ao banco de dados ou outro método dependendo da sua estrutura de dados

            // Por exemplo, vamos supor que o produto esteja no depósito e sua posição seja "Prateleira A"
            const posicao = "Prateleira A";
            const quantidade = 10; // Suponha que existam 10 unidades do produto na prateleira A

            // Retorna a posição e quantidade do produto no depósito
            return { posicao, quantidade };
        } catch (error) {
            throw error;
        }
    }

}


module.exports = depositService;