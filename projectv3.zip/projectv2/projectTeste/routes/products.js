// .routes/products.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const productService = require('../services/productService');// classe
const ProductService = new productService(db.Product);// Construção do objeto

const productController = require('../controllers/productController');// classe
const ProductController = new productController(ProductService);// Construção do objeto


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('Módulo de produtos está rodando.');
});

// Rota para criar um novo produto
router.post('/newProdutc', function(req, res, next){
  ProductController.create(req, res);
});

// Rota para localizar produto 
!!! como fazer !!!?
// router.get('/findProducts', function(req, res, next){
//     ProductController.findProducts(req, res);
// });


module.exports = router;
