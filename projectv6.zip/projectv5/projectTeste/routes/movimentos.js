// ./routes/movimentos.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const MovimentoProdutoService = require('../services/movimentoProdutoService');
const movimentoProdutoService = new MovimentoProdutoService(db.MovimentoProduto, db.Deposit, db.Product);

const MovimentoProdutoController = require('../controllers/movimentoProdutoController');
const movimentoProdutoController = new MovimentoProdutoController(movimentoProdutoService);

router.get('/findAll', (req, res) => movimentoProdutoController.findAll(req, res));
router.get('/findById/:movimentoId', (req, res) => movimentoProdutoController.findById(req, res));
router.post('/create', (req, res) => movimentoProdutoController.create(req, res));
router.post('/addProduct', (req, res) => movimentoProdutoController.addProductToDeposit(req, res));
router.post('/removeProduct', (req, res) => movimentoProdutoController.removeProductFromDeposit(req, res));

module.exports = router;
