// ./routes/department.js
var express = require('express');
var router = express.Router();

const db = require('../models');
const DepartmentService = require('../services/departmentService');
const departmentService = new DepartmentService(db.Department);

const DepartmentController = require('../controllers/departmentController');
const departmentController = new DepartmentController(departmentService);

// Routes
router.post('/create', (req, res) => departmentController.create(req, res));
router.get('/findAll', (req, res) => departmentController.findAll(req, res));
router.get('/findById/:departmentId', (req, res) => departmentController.findById(req, res));
router.put('/update/:departmentId', (req, res) => departmentController.update(req, res));
router.delete('/delete/:departmentId', (req, res) => departmentController.delete(req, res));

module.exports = router;
