// ./services/movimentoProdutoService.js
const db = require('../models');

class MovimentoProdutoService {
    constructor(movimentoProdutoModel, depositModel, productModel) {
        this.MovimentoProduto = movimentoProdutoModel;
        this.Deposit = depositModel;
        this.Product = productModel;
    }

    async create(data) {
        try {
            const novoMovimento = await this.MovimentoProduto.create(data);
            return novoMovimento;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allMovimentos = await this.MovimentoProduto.findAll();
            return allMovimentos;
        } catch (error) {
            throw error;
        }
    }

    async findById(movimentoId) {
        try {
            const movimento = await this.MovimentoProduto.findByPk(movimentoId);
            if (!movimento) {
                throw new Error(`Movimento com o ID ${movimentoId} não encontrado.`);
            }
            return movimento;
        } catch (error) {
            throw error;
        }
    }

    async addProductToDeposit(depositoId, produtoId, quantidade, precoUnitario) {
        const t = await db.sequelize.transaction();
        try {
            const produto = await this.Product.findByPk(produtoId, { transaction: t });
            if (!produto) {
                throw new Error(`Produto com o ID ${produtoId} não encontrado.`);
            }

            const deposito = await this.Deposit.findByPk(depositoId, { transaction: t });
            if (!deposito) {
                throw new Error(`Depósito com o ID ${depositoId} não encontrado.`);
            }

            const movimento = await this.MovimentoProduto.create({
                depositoId,
                produtoId,
                tipoMovimento: 'entrada',
                quantidade,
                precoUnitario,
                data: new Date()
            }, { transaction: t });

            // Adicionar lógica para atualizar o estoque

            await t.commit();
            return movimento;
        } catch (error) {
            await t.rollback();
            throw error;
        }
    }

    async removeProductFromDeposit(depositoId, produtoId, quantidade, precoUnitario) {
        const t = await db.sequelize.transaction();
        try {
            const produto = await this.Product.findByPk(produtoId, { transaction: t });
            if (!produto) {
                throw new Error(`Produto com o ID ${produtoId} não encontrado.`);
            }

            const deposito = await this.Deposit.findByPk(depositoId, { transaction: t });
            if (!deposito) {
                throw new Error(`Depósito com o ID ${depositoId} não encontrado.`);
            }

            const movimento = await this.MovimentoProduto.create({
                depositoId,
                produtoId,
                tipoMovimento: 'saida',
                quantidade,
                precoUnitario,
                data: new Date()
            }, { transaction: t });

            // Adicionar lógica para atualizar o estoque

            await t.commit();
            return movimento;
        } catch (error) {
            await t.rollback();
            throw error;
        }
    }
}

module.exports = MovimentoProdutoService;
