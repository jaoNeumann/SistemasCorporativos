//. /services/depositService.js
const db = require('../models');


class depositService{
    //construtor da classe recebe a depositModel
    constructor(depositModel){
        this.Deposit = depositModel;
    }
    async create(name, status) {
        try {
            const newDeposit = await this.Deposit.create({
                name: name,
                status: status
            });
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allDeposits = await this.Deposit.findAll();
            return allDeposits;
        } catch (error) {
            throw error;
        }
    }

    async findById(depositId) {
        try {
            const deposit = await this.Deposit.findByPk(depositId);
            if (!deposit) {
                throw new Error(`Depósito com o ID ${depositId} não encontrado.`);
            }
            return deposit;
        } catch (error) {
            throw error;
        }
    }

    async getPosicaoByProdutoInDeposito(productId, depositId) {
        try {
            // Verifica se o produto está no depósito
            const product = await this.Product.findByPk(productId);
            if (!product) {
                throw new Error(`Produto com o ID ${productId} não encontrado.`);
            }
    
            // Verifica se o depósito existe
            const deposit = await this.Deposit.findByPk(depositId);
            if (!deposit) {
                throw new Error(`Depósito com o ID ${depositId} não encontrado.`);
            }
    
            // Logica utilizando dados da model/moviment
            const moviment = await this.Moviment.findOne({
                where: {
                    productId: productId,
                    depositId: depositId
                }
            });
            if (!moviment) {
                throw new Error(`Produto com o ID ${productId} não encontrado no depósito com o ID ${depositId}.`);
            }
    
            // Retorna a posição e quantidade do produto no depósito
            const { posicao, quantidade } = moviment;
            return { posicao, quantidade };
        } catch (error) {
            throw error;
        }
    }
    

}


module.exports = depositService;