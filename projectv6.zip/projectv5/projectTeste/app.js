
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var productsRouter = require('./routes/products');
var movimentsRouter = require('./routes/moviments');
var departmentsRouter = require('./routes/departments');
    

const db = require('./models');

async function ApplyMigrations(){
    try {
        migration_config={
            create: true,
            alter: true
        };

        await db.sequelize.sync({
            alter: migration_config.alter
        });
        console.log('Sincronização com o banco de dados realizada.');
    } catch (error) {
        console.log('Erro sincronizando como banco de dados.', error);
    }
}

var app = express();
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/products', productsRouter);
app.use('/moviments', movimentsRouter);
app.use('/departments', departmentsRouter);


ApplyMigrations();

var port = '5000';
app.listen(port);

console.log("Rodou na porta " + port);

module.exports = app;
