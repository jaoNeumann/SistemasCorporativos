// ./controllers/movimentoProdutoController.js

class MovimentoProdutoController {
    constructor(movimentoProdutoService) {
        this.movimentoProdutoService = movimentoProdutoService;
    }

    async create(req, res) {
        const { depositoId, produtoId, tipoMovimento, quantidade, precoUnitario, data } = req.body;
        try {
            const novoMovimento = await this.movimentoProdutoService.create({ depositoId, produtoId, tipoMovimento, quantidade, precoUnitario, data });
            res.status(200).json(novoMovimento);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao inserir o novo movimento.' });
        }
    }

    async findAll(req, res) {
        try {
            const allMovimentos = await this.movimentoProdutoService.findAll();
            res.status(200).json(allMovimentos);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao buscar todos os movimentos.' });
        }
    }

    async findById(req, res) {
        const { movimentoId } = req.params;
        try {
            const movimento = await this.movimentoProdutoService.findById(movimentoId);
            res.status(200).json(movimento);
        } catch (error) {
            res.status(404).json({ error: error.message });
        }
    }

    async addProductToDeposit(req, res) {
        const { depositoId, produtoId, quantidade, precoUnitario } = req.body;
        try {
            const movimento = await this.movimentoProdutoService.addProductToDeposit(depositoId, produtoId, quantidade, precoUnitario);
            res.status(200).json(movimento);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async removeProductFromDeposit(req, res) {
        const { depositoId, produtoId, quantidade, precoUnitario } = req.body;
        try {
            const movimento = await this.movimentoProdutoService.removeProductFromDeposit(depositoId, produtoId, quantidade, precoUnitario);
            res.status(200).json(movimento);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = MovimentoProdutoController;
