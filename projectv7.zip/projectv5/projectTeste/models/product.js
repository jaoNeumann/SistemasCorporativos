// ./models/product.js
const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Product = sequelize.define('Product', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false
        }
    });

    Product.associate = (models) => {
        Product.belongsTo(models.Deposit, {
            foreignKey: 'depositoId',
            as: 'deposito'
        });
        Product.hasMany(models.MovimentoProduto, {
            foreignKey: 'produtoId',
            as: 'movimentos'
        });
    };

    return Product;
};
