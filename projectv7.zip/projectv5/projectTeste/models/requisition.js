// ./models/requisition.js
const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Requisition = sequelize.define('Requisition', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        userId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Users',
                key: 'id'
            }
        },
        productId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Products',
                key: 'id'
            }
        },
        quantity: {
            type: Sequelize.INTEGER,
            allowNull: false
        },
        costCenterId: {
            type: Sequelize.STRING,
            references: {
                model: 'CostCenters',
                key: 'id'
            }
        },
        status: {
            type: Sequelize.STRING,
            allowNull: false,
            defaultValue: 'pending' // 'pending', 'fulfilled', 'cancelled'
        }
    });
    return Requisition;
};
