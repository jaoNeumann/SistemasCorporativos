// ./models/purchase.js

const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Purchase = sequelize.define('Purchase', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        supplierId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Suppliers',
                key: 'id'
            }
        },
        costCenterId: {
            type: Sequelize.STRING,
            references: {
                model: 'CostCenters',
                key: 'id'
            }
        },
        totalAmount: {
            type: Sequelize.FLOAT,
            allowNull: false
        },
        purchaseDate: {
            type: Sequelize.DATE,
            allowNull: false
        },
        status: {
            type: Sequelize.STRING,
            allowNull: false,
            defaultValue: 'ordered' // 'ordered', 'received', 'paid'
        }
    });
    return Purchase;
};
