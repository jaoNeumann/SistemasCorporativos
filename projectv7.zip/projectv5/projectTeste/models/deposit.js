// ./models/deposit.js
const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Deposit = sequelize.define('Deposit', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        status: {
            type: Sequelize.BOOLEAN,
            allowNull: false,
            defaultValue: true
        }
    });

    Deposit.associate = (models) => {
        Deposit.hasMany(models.Product, {
            foreignKey: 'depositoId',
            as: 'products'
        });
        Deposit.hasMany(models.MovimentoProduto, {
            foreignKey: 'depositoId',
            as: 'movimentos'
        });
    };

    return Deposit;
};