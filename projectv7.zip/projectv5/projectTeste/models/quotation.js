// ./models/quotation.js
const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Quotation = sequelize.define('Quotation', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        productId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Products',
                key: 'id'
            }
        },
        supplierId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Suppliers',
                key: 'id'
            }
        },
        price: {
            type: Sequelize.FLOAT,
            allowNull: false
        },
        quotationDate: {
            type: Sequelize.DATE,
            allowNull: false
        },
        validityDate: {
            type: Sequelize.DATE,
            allowNull: false
        },
        buyerId: {
            type: Sequelize.INTEGER,
            references: {
                model: 'Users',
                key: 'id'
            }
        }
    });
    return Quotation;
};
