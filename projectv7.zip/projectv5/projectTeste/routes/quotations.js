// ./routes/quotations.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const QuotationService = require('../services/quotationService');
const quotationService = new QuotationService(db.Quotation);

const QuotationController = require('../controllers/quotationController');
const quotationController = new QuotationController(quotationService);

// Routes
router.post('/create', (req, res) => quotationController.create(req, res));
router.get('/findAll', (req, res) => quotationController.findAll(req, res));
router.get('/findById/:quotationId', (req, res) => quotationController.findById(req, res));

module.exports = router;
