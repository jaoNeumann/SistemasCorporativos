// ./routes/purchases.js
var express = require('express');
var router = express.Router();

const db = require('../models');
const PurchaseService = require('../services/purchaseService');
const purchaseService = new PurchaseService(db.Purchase);

const PurchaseController = require('../controllers/purchaseController');
const purchaseController = new PurchaseController(purchaseService);

// Routes
router.post('/createFromQuotation', (req, res) => purchaseController.createFromQuotation(req, res));
router.get('/findAll', (req, res) => purchaseController.findAll(req, res));
router.get('/findById/:purchaseId', (req, res) => purchaseController.findById(req, res));
router.put('/updateStatus/:purchaseId', (req, res) => purchaseController.updateStatus(req, res));

module.exports = router;
