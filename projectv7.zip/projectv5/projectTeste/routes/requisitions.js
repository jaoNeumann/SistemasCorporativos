// ./router/requisitions.js
var express = require('express');
var router = express.Router();

const db = require('../models');
const requisitionService = require('../services/requisitionService');
const requisitionService = new RequisitionService(db.Requisition);

const requisitionController = require('../controllers/requisitionController');
const requisitionController = new RequisitionController(requisitionService);

// Routes
router.post('/create', (req, res) => requisitionController.create(req, res));
router.get('/findAll', (req, res) => requisitionController.findAll(req, res));
router.get('/findById/:requisitionId', (req, res) => requisitionController.findById(req, res));
router.put('/updateStatus/:requisitionId', (req, res) => requisitionController.updateStatus(req, res));

module.exports = router;
