// ./routes/suppliers.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const SupplierService = require('../services/supplierService');
const supplierService = new SupplierService(db.Supplier);

const SupplierController = require('../controllers/supplierController');
const supplierController = new SupplierController(supplierService);

// Routes
router.post('/create', (req, res) => supplierController.create(req, res));
router.get('/findAll', (req, res) => supplierController.findAll(req, res));
router.get('/findById/:supplierId', (req, res) => supplierController.findById(req, res));
router.put('/update/:supplierId', (req, res) => supplierController.update(req, res));
router.delete('/delete/:supplierId', (req, res) => supplierController.delete(req, res));

module.exports = router;
