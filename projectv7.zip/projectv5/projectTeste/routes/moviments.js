// ./routes/movimentos.js

var express = require('express');
var router = express.Router();

const db = require('../models');
const MovimentoProdutoService = require('../services/movimentoProdutoService');
const movimentoProdutoService = new MovimentoProdutoService(db.MovimentoProduto, db.Deposit, db.Product);

const MovimentoProdutoController = require('../controllers/movimentoProdutoController');
const movimentoProdutoController = new MovimentoProdutoController(movimentoProdutoService);

router.get('/', function(req, res, next) {
    res.send('Módulo de movimentos de produtos está rodando.');
});
router.post('/create', function(req, res, next) {
    movimentoProdutoController.create(req, res);
});

router.get('/todosMovimentos', function(req, res, next) {
    movimentoProdutoController.findAll(req, res);
});

router.get('/movimento/:movimentoId', function(req, res, next) {
    movimentoProdutoController.findById(req, res);
});

router.post('/addProduct', function(req, res, next) {
    movimentoProdutoController.addProductToDeposit(req, res);
});

router.post('/removeProduct', function(req, res, next) {
    movimentoProdutoController.removeProductFromDeposit(req, res);
});

module.exports = router;
