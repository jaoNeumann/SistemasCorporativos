// ./routes/costCenters.js
var express = require('express');
var router = express.Router();

const db = require('../models');
const CostCenterService = require('../services/costCenterService');
const costCenterService = new CostCenterService(db.CostCenter);

const CostCenterController = require('../controllers/costCenterController');
const costCenterController = new CostCenterController(costCenterService);

// Routes
router.post('/create', (req, res) => costCenterController.create(req, res));
router.get('/findAll', (req, res) => costCenterController.findAll(req, res));
router.get('/findById/:costCenterId', (req, res) => costCenterController.findById(req, res));
router.put('/update/:costCenterId', (req, res) => costCenterController.update(req, res));
router.delete('/delete/:costCenterId', (req, res) => costCenterController.delete(req, res));

module.exports = router;
