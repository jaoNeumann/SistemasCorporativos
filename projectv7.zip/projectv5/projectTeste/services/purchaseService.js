// ./services/purchaseService.js
const db = require('../models');

class PurchaseService {
    constructor(purchaseModel) {
        this.Purchase = purchaseModel;
    }

    async createFromQuotation(quotationId) {
        try {
            const quotation = await db.Quotation.findByPk(quotationId, {
                include: ['Requisition', 'Supplier']
            });

            if (!quotation) {
                throw new Error(`Quotation with ID ${quotationId} not found.`);
            }

            const newPurchase = await this.Purchase.create({
                supplierId: quotation.supplierId,
                costCenterId: quotation.Requisition.costCenterId,
                totalAmount: quotation.price * quotation.Requisition.quantity,
                purchaseDate: new Date(),
                status: 'ordered'
            });

            return newPurchase;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allPurchases = await this.Purchase.findAll({
                include: ['Supplier', 'CostCenter']
            });
            return allPurchases;
        } catch (error) {
            throw error;
        }
    }

    async findById(purchaseId) {
        try {
            const purchase = await this.Purchase.findByPk(purchaseId, {
                include: ['Supplier', 'CostCenter']
            });
            if (!purchase) {
                throw new Error(`Purchase with ID ${purchaseId} not found.`);
            }
            return purchase;
        } catch (error) {
            throw error;
        }
    }

    async updateStatus(purchaseId, status) {
        try {
            const [updatedRowsCount, updatedRows] = await this.Purchase.update({ status }, {
                where: { id: purchaseId },
                returning: true
            });
            if (updatedRowsCount === 0) {
                throw new Error(`Purchase with ID ${purchaseId} not found.`);
            }
            return updatedRows[0];
        } catch (error) {
            throw error;
        }
    }
}

module.exports = PurchaseService;
