// ./services/supplierService.js
const db = require('../models');

class SupplierService {
    constructor(supplierModel) {
        this.Supplier = supplierModel;
    }

    async create(name, contact) {
        try {
            const newSupplier = await this.Supplier.create({ name, contact });
            return newSupplier;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allSuppliers = await this.Supplier.findAll();
            return allSuppliers;
        } catch (error) {
            throw error;
        }
    }

    async findById(supplierId) {
        try {
            const supplier = await this.Supplier.findByPk(supplierId);
            if (!supplier) {
                throw new Error(`Supplier with ID ${supplierId} not found.`);
            }
            return supplier;
        } catch (error) {
            throw error;
        }
    }

    async update(supplierId, newData) {
        try {
            const [updatedRowsCount, updatedRows] = await this.Supplier.update(newData, {
                where: { id: supplierId },
                returning: true
            });
            if (updatedRowsCount === 0) {
                throw new Error(`Supplier with ID ${supplierId} not found.`);
            }
            return updatedRows[0];
        } catch (error) {
            throw error;
        }
    }

    async delete(supplierId) {
        try {
            const rowsDeleted = await this.Supplier.destroy({
                where: { id: supplierId }
            });
            if (rowsDeleted === 0) {
                throw new Error(`Supplier with ID ${supplierId} not found.`);
            }
        } catch (error) {
            throw error;
        }
    }
}

module.exports = SupplierService;
