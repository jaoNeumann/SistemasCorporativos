// ./services/productService.js
const db = require('../models');


class productService{
    //construtor da classe recebe a productModel
    constructor(productModel){
        this.Product = productModel;
    }
    async create(name, status) {
        try {
            const newProduct = await this.Product.create({
                name: name,
                status: status
            });
        } catch (error) {
            throw error;
        }
    }

    async update(productId, newData) {
        try {
            const [updatedRowsCount, updatedRows] = await this.Product.update(newData, {
                where: { id: productId },
                returning: true // para retornar as linhas atualizadas
            });

            if (updatedRowsCount === 0) {
                throw new Error(`Produto com o código ${productId} não encontrado.`);
            }

            return updatedRows[0]; // Retorna o primeiro produto atualizado
        } catch (error) {
            throw error;
        }
    }    
    
    async findAll() {
        try {
            const allProducts = await this.Product.findAll();
            return allProducts;
        } catch (error) {
            throw error;
        }
    }

    async findById(productId) {
        try {
            const product = await this.Product.findByPk(productId);
            if (!product) {
                throw new Error(`Produto com o ID ${productId} não encontrado.`);
            }
            return product;
        } catch (error) {
            throw error;
        }
    }

}
module.exports = productService;