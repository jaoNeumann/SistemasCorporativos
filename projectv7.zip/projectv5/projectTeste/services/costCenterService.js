// ./services/costCenterService.js
const db = require('../models');

class CostCenterService {
    constructor(costCenterModel) {
        this.CostCenter = costCenterModel;
    }

    async create(id, name) {
        try {
            const newCostCenter = await this.CostCenter.create({ id, name });
            return newCostCenter;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allCostCenters = await this.CostCenter.findAll();
            return allCostCenters;
        } catch (error) {
            throw error;
        }
    }

    async findById(costCenterId) {
        try {
            const costCenter = await this.CostCenter.findByPk(costCenterId);
            if (!costCenter) {
                throw new Error(`Cost Center with ID ${costCenterId} not found.`);
            }
            return costCenter;
        } catch (error) {
            throw error;
        }
    }

    async update(costCenterId, newData) {
        try {
            const [updatedRowsCount, updatedRows] = await this.CostCenter.update(newData, {
                where: { id: costCenterId },
                returning: true
            });
            if (updatedRowsCount === 0) {
                throw new Error(`Cost Center with ID ${costCenterId} not found.`);
            }
            return updatedRows[0];
        } catch (error) {
            throw error;
        }
    }

    async delete(costCenterId) {
        try {
            const rowsDeleted = await this.CostCenter.destroy({
                where: { id: costCenterId }
            });
            if (rowsDeleted === 0) {
                throw new Error(`Cost Center with ID ${costCenterId} not found.`);
            }
        } catch (error) {
            throw error;
        }
    }
}

module.exports = CostCenterService;
