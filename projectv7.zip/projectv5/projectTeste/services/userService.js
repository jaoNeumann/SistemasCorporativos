//. /services/userService.js
const db = require('../models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');


class userService{
    //construtor da classe recebe a userModel
    constructor(userModel){
        this.User = userModel;
    }
    async create(login, nome, email, senha, departmentId) {
        try {
            const hashedSenha = await bcrypt.hash(senha, 5);
            const novoUser = await this.User.create({
                login: login,
                nome: nome,
                email: email,
                departmento: departmentId,
                senha: hashedSenha // Salva a senha encriptada no banco de dados
            });
            novoUser.senha = "nabo";
            return novoUser ? novoUser : null;
        } catch (error) {
            throw error;
        }
    }
    // localizaTodosUsuarios
    async localizaTodosUsuarios(login, senha){
        try {
            const AllUsers = await this.User.findAll();
            return AllUsers? AllUsers: null;
        } catch (error) {
            throw error;
        }
    }
    
    // localiza usuario pelo ID
    async localisaUsuarioId(login, id){
        try {
            const OneUser = await this.User.findByPk(id);
            return OneUser? OneUser: null;
        } catch (error) {
            throw error;
        }
    }

    // login
    async login(login, senha) {
        try {
            const user = await this.User.findOne({ where: { login: login } });
            if (!user) {
                return res.status(401).json({ error: 'Usuário não encontrado' });
            }
            const senhaValida = await bcrypt.compare(senha, user.senha);
            if (!senhaValida) {
                return res.status(401).json({ error: 'Credenciais inválidas' });
            }
            const token = await jwt.sign({ id: user.id }, 'MareaTurbo1.9', { expiresIn: '1h' });
            return ( token );
        } catch (error) {
            res.status(500).json({ error: 'Erro ao realizar login' });
        }
    }
    
}



module.exports = userService;