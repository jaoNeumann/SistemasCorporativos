// ./services/requisition.js
const db = require('../models');

class RequisitionService {
    constructor(requisitionModel) {
        this.Requisition = requisitionModel;
    }

    async create(userId, productId, quantity, costCenterId) {
        try {
            const newRequisition = await this.Requisition.create({ userId, productId, quantity, costCenterId });
            return newRequisition;
        } catch (error) {
            throw error;
        }
    }

    async findAll() {
        try {
            const allRequisitions = await this.Requisition.findAll({
                include: ['User', 'Product', 'CostCenter']
            });
            return allRequisitions;
        } catch (error) {
            throw error;
        }
    }

    async findById(requisitionId) {
        try {
            const requisition = await this.Requisition.findByPk(requisitionId, {
                include: ['User', 'Product', 'CostCenter']
            });
            if (!requisition) {
                throw new Error(`Requisition with ID ${requisitionId} not found.`);
            }
            return requisition;
        } catch (error) {
            throw error;
        }
    }

    async updateStatus(requisitionId, status) {
        try {
            const [updatedRowsCount, updatedRows] = await this.Requisition.update({ status }, {
                where: { id: requisitionId },
                returning: true
            });
            if (updatedRowsCount === 0) {
                throw new Error(`Requisition with ID ${requisitionId} not found.`);
            }
            return updatedRows[0];
        } catch (error) {
            throw error;
        }
    }
}

module.exports = requisitionService;
