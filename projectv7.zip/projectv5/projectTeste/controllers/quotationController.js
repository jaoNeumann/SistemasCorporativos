// ./controller/quotationController.js

class QuotationController {
    constructor(quotationService) {
        this.quotationService = quotationService;
    }

    async create(req, res) {
        const { requisitionId, supplierId, price, validUntil, userId } = req.body;
        try {
            const quotations = await this.quotationService.create(requisitionId, supplierId, price, validUntil, userId);
            res.status(201).json(quotations);
        } catch (error) {
            res.status(500).json({ error: 'Error creating quotations.' });
        }
    }

    async findAll(req, res) {
        try {
            const quotations = await this.quotationService.findAll();
            res.status(200).json(quotations);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching quotations.' });
        }
    }

    async findById(req, res) {
        const { quotationId } = req.params;
        try {
            const quotation = await this.quotationService.findById(quotationId);
            res.status(200).json(quotation);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching quotation.' });
        }
    }
}

module.exports = QuotationController;
