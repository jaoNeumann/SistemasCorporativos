// ./controllers/departmentController.js
class DepartmentController {
    constructor(departmentService) {
        this.departmentService = departmentService;
    }

    async create(req, res) {
        const { name } = req.body;
        try {
            const newDepartment = await this.departmentService.create(name);
            res.status(201).json(newDepartment);
        } catch (error) {
            res.status(500).json({ error: 'Error creating department.' });
        }
    }

    async findAll(req, res) {
        try {
            const departments = await this.departmentService.findAll();
            res.status(200).json(departments);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching departments.' });
        }
    }

    async findById(req, res) {
        const { departmentId } = req.params;
        try {
            const department = await this.departmentService.findById(departmentId);
            res.status(200).json(department);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching department.' });
        }
    }

    async update(req, res) {
        const { departmentId } = req.params;
        const newData = req.body;
        try {
            const updatedDepartment = await this.departmentService.update(departmentId, newData);
            res.status(200).json(updatedDepartment);
        } catch (error) {
            res.status(500).json({ error: 'Error updating department.' });
        }
    }

    async delete(req, res) {
        const { departmentId } = req.params;
        try {
            await this.departmentService.delete(departmentId);
            res.status(200).json({ message: 'Department deleted successfully.' });
        } catch (error) {
            res.status(500).json({ error: 'Error deleting department.' });
        }
    }
}

module.exports = DepartmentController;
