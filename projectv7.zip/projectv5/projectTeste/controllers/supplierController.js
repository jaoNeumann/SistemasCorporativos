// ./controllers/userController.js

class SupplierController {
    constructor(supplierService) {
        this.supplierService = supplierService;
    }

    async create(req, res) {
        const { name, contact } = req.body;
        try {
            const newSupplier = await this.supplierService.create(name, contact);
            res.status(201).json(newSupplier);
        } catch (error) {
            res.status(500).json({ error: 'Error creating supplier.' });
        }
    }

    async findAll(req, res) {
        try {
            const suppliers = await this.supplierService.findAll();
            res.status(200).json(suppliers);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching suppliers.' });
        }
    }

    async findById(req, res) {
        const { supplierId } = req.params;
        try {
            const supplier = await this.supplierService.findById(supplierId);
            res.status(200).json(supplier);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching supplier.' });
        }
    }

    async update(req, res) {
        const { supplierId } = req.params;
        const newData = req.body;
        try {
            const updatedSupplier = await this.supplierService.update(supplierId, newData);
            res.status(200).json(updatedSupplier);
        } catch (error) {
            res.status(500).json({ error: 'Error updating supplier.' });
        }
    }

    async delete(req, res) {
        const { supplierId } = req.params;
        try {
            await this.supplierService.delete(supplierId);
            res.status(200).json({ message: 'Supplier deleted successfully.' });
        } catch (error) {
            res.status(500).json({ error: 'Error deleting supplier.' });
        }
    }
}

module.exports = SupplierController;
