// ./controllers/requisitionController.js

class RequisitionController {
    constructor(requisitionService) {
        this.requisitionService = requisitionService;
    }

    async create(req, res) {
        const { userId, productId, quantity, costCenterId } = req.body;
        try {
            const newRequisition = await this.requisitionService.create(userId, productId, quantity, costCenterId);
            res.status(201).json(newRequisition);
        } catch (error) {
            res.status(500).json({ error: 'Error creating requisition.' });
        }
    }

    async findAll(req, res) {
        try {
            const requisitions = await this.requisitionService.findAll();
            res.status(200).json(requisitions);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching requisitions.' });
        }
    }

    async findById(req, res) {
        const { requisitionId } = req.params;
        try {
            const requisition = await this.requisitionService.findById(requisitionId);
            res.status(200).json(requisition);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching requisition.' });
        }
    }

    async updateStatus(req, res) {
        const { requisitionId } = req.params;
        const { status } = req.body;
        try {
            const updatedRequisition = await this.requisitionService.updateStatus(requisitionId, status);
            res.status(200).json(updatedRequisition);
        } catch (error) {
            res.status(500).json({ error: 'Error updating requisition status.' });
        }
    }
}

module.exports = RequisitionController;
