// ./controllers/purchaseController.js
class PurchaseController {
    constructor(purchaseService) {
        this.purchaseService = purchaseService;
    }

    async createFromQuotation(req, res) {
        const { quotationId } = req.body;
        try {
            const newPurchase = await this.purchaseService.createFromQuotation(quotationId);
            res.status(201).json(newPurchase);
        } catch (error) {
            res.status(500).json({ error: 'Error creating purchase from quotation.' });
        }
    }

    async findAll(req, res) {
        try {
            const purchases = await this.purchaseService.findAll();
            res.status(200).json(purchases);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching purchases.' });
        }
    }

    async findById(req, res) {
        const { purchaseId } = req.params;
        try {
            const purchase = await this.purchaseService.findById(purchaseId);
            res.status(200).json(purchase);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching purchase.' });
        }
    }

    async updateStatus(req, res) {
        const { purchaseId } = req.params;
        const { status } = req.body;
        try {
            const updatedPurchase = await this.purchaseService.updateStatus(purchaseId, status);
            res.status(200).json(updatedPurchase);
        } catch (error) {
            res.status(500).json({ error: 'Error updating purchase status.' });
        }
    }
}

module.exports = PurchaseController;
