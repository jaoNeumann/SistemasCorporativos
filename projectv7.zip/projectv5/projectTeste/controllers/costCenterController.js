// .controllers/costCenterController.js
class CostCenterController {
    constructor(costCenterService) {
        this.costCenterService = costCenterService;
    }

    async create(req, res) {
        const { id, name } = req.body;
        try {
            const newCostCenter = await this.costCenterService.create(id, name);
            res.status(201).json(newCostCenter);
        } catch (error) {
            res.status(500).json({ error: 'Error creating cost center.' });
        }
    }

    async findAll(req, res) {
        try {
            const costCenters = await this.costCenterService.findAll();
            res.status(200).json(costCenters);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching cost centers.' });
        }
    }

    async findById(req, res) {
        const { costCenterId } = req.params;
        try {
            const costCenter = await this.costCenterService.findById(costCenterId);
            res.status(200).json(costCenter);
        } catch (error) {
            res.status(500).json({ error: 'Error fetching cost center.' });
        }
    }

    async update(req, res) {
        const { costCenterId } = req.params;
        const newData = req.body;
        try {
            const updatedCostCenter = await this.costCenterService.update(costCenterId, newData);
            res.status(200).json(updatedCostCenter);
        } catch (error) {
            res.status(500).json({ error: 'Error updating cost center.' });
        }
    }

    async delete(req, res) {
        const { costCenterId } = req.params;
        try {
            await this.costCenterService.delete(costCenterId);
            res.status(200).json({ message: 'Cost Center deleted successfully.' });
        } catch (error) {
            res.status(500).json({ error: 'Error deleting cost center.' });
        }
    }
}

module.exports = CostCenterController;
