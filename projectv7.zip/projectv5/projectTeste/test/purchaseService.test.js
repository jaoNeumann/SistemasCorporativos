const { expect } = require('chai');
const db = require('../models');
const PurchaseService = require('../services/purchaseService');
const purchaseService = new PurchaseService(db.Purchase);

describe('PurchaseService', () => {
    describe('createFromQuotation', () => {
        it('should create a new purchase from a quotation', async () => {
            const quotation = await db.Quotation.create({
                requisitionId: 1,
                supplierId: 1,
                price: 100.0,
                validUntil: new Date(),
                userId: 1
            });

            const purchase = await purchaseService.createFromQuotation(quotation.id);
            expect(purchase).to.have.property('id');
            expect(purchase.supplierId).to.equal(quotation.supplierId);
        });
    });

    describe('findAll', () => {
        it('should return all purchases', async () => {
            const purchases = await purchaseService.findAll();
            expect(purchases).to.be.an('array');
        });
    });

    describe('findById', () => {
        it('should return a purchase by id', async () => {
            const quotation = await db.Quotation.create({
                requisitionId: 1,
                supplierId: 2,
                price: 200.0,
                validUntil: new Date(),
                userId: 2
            });

            const purchase = await purchaseService.createFromQuotation(quotation.id);
            const foundPurchase = await purchaseService.findById(purchase.id);
            expect(foundPurchase).to.have.property('id');
            expect(foundPurchase.supplierId).to.equal(quotation.supplierId);
        });
    });

    describe('updateStatus', () => {
        it('should update the status of a purchase', async () => {
            const quotation = await db.Quotation.create({
                requisitionId: 1,
                supplierId: 3,
                price: 300.0,
                validUntil: new Date(),
                userId: 3
            });

            const purchase = await purchaseService.createFromQuotation(quotation.id);
            const updatedPurchase = await purchaseService.updateStatus(purchase.id, 'received');
            expect(updatedPurchase.status).to.equal('received');
        });
    });
});
