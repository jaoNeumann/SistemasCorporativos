// ./controllers/depositController.js

class depositController{
    constructor(depositService){
        this.despoitService = depositService;
    }
    // Metodo create
    async create(req, res){
        const {name, status} = req.body;
        try {
            const newdeposit = await this.depositService.create(name, status);
            res.status(200).json(newDeposit);
        } catch (error) {
            res.status(500).json({error:'Erro ao inserir o novo deposito.'});
        }
    }

}

module.exports = depositController;