// ./controllers/productController.js

class productController{
    constructor(productService){
        this.productService = productService;
    }
    // Metodo create
    async create(req, res){
        const {name, status} = req.body;
        try {
            const newProduct = await this.productService.create(name, status);
            res.status(200).json(newProduct);
        } catch (error) {
            res.status(500).json({error:'Erro ao inserir o novo produto.'});
        }
    }

    // Metodo lista produtos (necessário receber identificação do deposito)
    async update(req, res) {
        const { productId } = req.id;
        const newData = req.body;
        try {
            const updatedProduct = await this.productService.update(productId, newData);
            res.status(200).json(updatedProduct);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao atualizar o produto.' });
        }
    }
}

module.exports = productController;