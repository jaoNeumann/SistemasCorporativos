// ./models/deposit.js
const Sequelize = require('sequelize');

module.exports= (sequelize) => {
    const Deposit = sequelize.define('Deposit',{
        id:{
            type: Sequelize.INTEGER,
            primaryKey:true,
            autoIncrement: true
        },
        name:{
            type:Sequelize.STRING,
            allowNull:false,
        },
        status:{
            type:Sequelize.BOOLEAN,
            allowNull:false,
            default: true
        }
    });
    return Deposit;
};

