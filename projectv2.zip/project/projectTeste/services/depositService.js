//. /services/depositService.js
const db = require('../models');


class depositService{
    //construtor da classe recebe a depositModel
    constructor(depositModel){
        this.Deposit = depositModel;
    }
    async create(name, status) {
        try {
            const newDeposit = await this.Deposit.create({
                name: name,
                status: status
            });
        } catch (error) {
            throw error;
        }
    }

    // localiza todos os produtos dentro desse deposito
    async localizaTodosUsuarios(login, senha){
        try {
            const AllUsers = await this.User.findAll();
            return AllUsers? AllUsers: null;
        } catch (error) {
            throw error;
        }
    }    
}


module.exports = depositService;